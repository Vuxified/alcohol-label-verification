Sample batch for Label Check
============================
manifest.csv lists 22 applications; their label images are in this ZIP.
20 are generated labels (made for this project, not real products): about half match their application and
half have a known problem, such as a wrong alcohol content or a reworded health warning.
Rows SAMPLE-21 and SAMPLE-22 are broken on purpose: one image is missing from the ZIP, and one image is damaged.
They show up as errors without stopping the rest of the batch.
